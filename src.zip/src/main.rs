mod mw_event;

slint::include_modules!();

#[tokio::main]
async fn main() {
    let mw = MainWindow::new().unwrap();
    let mw_weak = mw.as_weak();
    mw.on_button_play_run(move || {

        let mw_weak = mw_weak.clone();

        tokio::spawn(async move {
            let _ = minecrat(mw_weak).await;5
        });
    });

    mw.run().unwrap();
}
use lyceris::minecraft::{
    config::ConfigBuilder,
    emitter::{Emitter, Event},
    install::install,
    launch::launch,
};
use lyceris::minecraft::loader::neoforge::NeoForge;

use std::path::PathBuf;

async fn minecrat(mw_weak: slint::Weak<MainWindow>, ) -> Result<(), Box<dyn std::error::Error>> {
    //mw_event::play(mw_weak.clone(), "Загрузка...");
    mw_event::look(mw_weak.clone(), true);
    let emitter = Emitter::default();
    let mw_weak2 = mw_weak.clone();


    emitter
        .on(
            Event::MultipleDownloadProgress,
            move |(path, current, total): (String, u64, u64)| {
                println!("Downloading {} - {}/{}", path, current, total);
                let event = format!("{}", current);
                //mw_event::play(mw_weak2.clone(), &event);
            },
        )
        .await;
    //в настройки
    emitter
        .on(Event::Console, |line: String| {
            println!("Line: {}", line);
        })
        .await;

    let local_appdata = std::env::var("LOCALAPPDATA")?;


    let config = ConfigBuilder::new(
        PathBuf::from(local_appdata).join("OliviaLauncher"),
        "1.21.1".into(),
        lyceris::auth::AuthMethod::Offline {
            username: "Lyceris".into(),
            uuid: None,

        },
    )
        .loader(NeoForge("21.1.233".to_string()).into())
        .build();

    install(&config, Some(&emitter)).await?;

    let mut child = launch(&config, Some(&emitter)).await?;
    child.wait().await?;
    mw_event::look(mw_weak.clone(), false);
    Ok(())
}